// Lifecycle-only CPU cost, no database: drives the module's own hooks with a fake request.
//   node micro.mjs <path to packages/payload-roles/src> [label]
// Prints ns per operation (median of ROUNDS rounds). An upper bound for what a pure-CPU change in
// src/lifecycle can save; compare it with the end-to-end op time before believing it matters.
import { performance } from "node:perf_hooks";

const [src, label = "src"] = process.argv.slice(2);
const { lifecycle } = await import(`${src}/lifecycle/index.ts`);

const ROUNDS = 15;
const PER_ROUND = 3000;
const BULK = 20;

const resourceOf = (id, kind, flags, actions) => ({
  id,
  kind,
  slug: id.split(":")[1],
  auth: false,
  unlock: false,
  ...flags,
  actions: new Set(actions),
});
const pages = resourceOf(
  "collections:pages",
  "collection",
  { drafts: true, trash: true, versions: true },
  ["read", "create", "update", "delete", "trash", "publish", "unpublish", "readVersions"],
);
const posts = resourceOf(
  "collections:posts",
  "collection",
  { drafts: false, trash: false, versions: false },
  ["read", "create", "update", "delete"],
);

const grantsOf = (resource, actions) => new Set(actions.map((action) => `${resource.id}#${action}`));
const ALL = grantsOf(pages, [...pages.actions]);
const PARTIAL = grantsOf(pages, ["read", "update", "publish"]);

const enforcerOf = (grants) => ({
  options: { userCollection: "users" },
  registry: new Map(),
  subject: async () => ({ kind: "member", id: 1, capabilities: { kind: "grants", grants } }),
  log: { debug() {}, warn() {}, error() {} },
});

const reqOf = () => ({
  payloadDataLoader: {},
  query: {},
  t: (key) => key,
  payload: { db: { findOne: async () => ({ id: 1, _status: "draft", deletedAt: null }) } },
});

// `enterWith` leaks into the caller's context, so each operation starts from a fresh macrotask.
const isolated = (fn) =>
  new Promise((resolve, reject) => {
    setImmediate(() => fn().then(resolve, reject));
  });

const write = (grants, { body, filled, docs }) => {
  const hooks = lifecycle.collectionHooks(pages, enforcerOf(grants));
  const [trailing] = hooks.beforeOperation;
  const [beforeChange] = hooks.beforeChange;
  return async () => {
    const req = reqOf();
    const args = { data: body, id: docs === 1 ? 7 : undefined, where: {} };
    const start = performance.now();
    hooks.leadingBeforeOperation({ args, operation: "update", overrideAccess: false, req });
    await trailing({ args, collection: { upload: false }, operation: "update", req });
    for (let index = 0; index < docs; index += 1) {
      // eslint-disable-next-line no-await-in-loop
      await beforeChange({ data: filled, operation: "update", originalDoc: { id: 7 + index }, req });
    }
    return performance.now() - start;
  };
};

const probe = (resource, data) => {
  const req = reqOf();
  return async () => {
    const start = performance.now();
    for (let index = 0; index < 100; index += 1) {
      lifecycle.requiredWriteActions({ resource, key: "update", data, id: 7, req });
    }
    return (performance.now() - start) / 100;
  };
};

const live = { _status: "published", deletedAt: null, title: "x" };
const draft = { _status: "draft", deletedAt: null, title: "x" };
const CASES = {
  "update by id, all grants (plan + 1 check)": write(ALL, { body: live, filled: live, docs: 1 }),
  [`bulk ${BULK}, all grants (plan + ${BULK} checks)`]: write(ALL, {
    body: { title: "x" },
    filled: live,
    docs: BULK,
  }),
  [`bulk ${BULK} draft edit, partial grants (plan + ${BULK} checks + ${BULK} fake reads)`]: write(
    PARTIAL,
    { body: { title: "x" }, filled: draft, docs: BULK },
  ),
  "probe requiredWriteActions, governed pages": probe(pages, live),
  "probe requiredWriteActions, ungoverned posts": probe(posts, { title: "x" }),
};

const median = (values) => values.toSorted((a, b) => a - b)[Math.floor(values.length / 2)];
const out = {};
for (const [name, run] of Object.entries(CASES)) {
  for (let warm = 0; warm < PER_ROUND; warm += 1) {
    // eslint-disable-next-line no-await-in-loop
    await isolated(run);
  }
  const rounds = [];
  for (let round = 0; round < ROUNDS; round += 1) {
    let total = 0;
    for (let index = 0; index < PER_ROUND; index += 1) {
      // eslint-disable-next-line no-await-in-loop
      total += await isolated(run);
    }
    rounds.push((total / PER_ROUND) * 1e6);
  }
  out[name] = {
    medianNs: Math.round(median(rounds)),
    minNs: Math.round(Math.min(...rounds)),
    maxNs: Math.round(Math.max(...rounds)),
  };
}
console.log(JSON.stringify({ label, node: process.version, rounds: ROUNDS, perRound: PER_ROUND, cases: out }));
