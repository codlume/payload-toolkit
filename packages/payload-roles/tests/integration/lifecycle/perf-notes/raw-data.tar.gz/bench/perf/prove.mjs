// What the lifecycle's own reads ask for and get, on whichever dist is in the package now.
//   cd packages/payload-roles && node <this file>
// Prints every payload.db read the plugin's code makes during: a no-trash member's live edit, the
// same edit of a page whose main row is in the trash (must be refused), a no-unpublish member's
// draft edit of the settings global, and a full member's and a partial member's global restore.
import { pathToFileURL } from "node:url";

const helpers = `${process.cwd()}/tests/helpers`;
const { as, login, rest, seedRole, seedUser } = await import(pathToFileURL(`${helpers}/actors.ts`));
const { createTestPayload } = await import(pathToFileURL(`${helpers}/payload.ts`));

const context = await createTestPayload({ name: "lifecycle-prove" });
const { payload } = context;
await seedUser(payload, { email: "bootstrap@example.com" });
const member = async (key, permissions) =>
  seedUser(payload, { email: `${key}@example.com`, roles: [await seedRole(payload, key, permissions)] });
const partial = await member("partial", {
  collections: { pages: { actions: ["read", "update", "publish"] } },
  globals: { settings: { actions: ["read", "update", "publish", "readVersions"] } },
});
const full = await member("full", {
  globals: { settings: { actions: ["read", "update", "publish", "unpublish", "readVersions"] } },
});

const seen = [];
for (const name of ["findOne", "findGlobal", "findGlobalVersions"]) {
  const original = payload.db[name];
  payload.db[name] = async function traced(args) {
    const result = await original.call(this, args);
    const fromPlugin = /payload-roles\/dist\/index\.mjs/u.test(new Error("trace").stack.split("\n")[2] ?? "");
    if (fromPlugin) {
      const row = name === "findGlobalVersions" ? result.docs[0] : result;
      seen.push(`${name} select=${JSON.stringify(args.select)} -> keys ${JSON.stringify(Object.keys(row ?? {}))} deletedAt=${JSON.stringify(row?.deletedAt)}`);
    }
    return result;
  };
}
const step = async (label, run) => {
  seen.length = 0;
  let outcome;
  try {
    await run();
    outcome = "allowed";
  } catch (error) {
    outcome = `${error.name}`;
  }
  console.log(`${label}: ${outcome}`);
  for (const line of seen) {
    console.log(`    ${line}`);
  }
  if (seen.length === 0) {
    console.log("    no plugin read");
  }
};

const live = await payload.create({ collection: "pages", data: { _status: "published", title: "live" } });
await step("no-trash member, live edit of a live page", () =>
  as(payload, partial).update({ collection: "pages", data: { _status: "published", title: "edited" }, id: live.id }),
);

const TRASHED = "2026-01-01T00:00:00.000Z";
const trashed = await payload.create({
  collection: "pages",
  data: { _status: "published", deletedAt: TRASHED, title: "trashed" },
});
const token = await login(payload, partial.email);
const draftSave = await rest(context, token)("PATCH", `/pages/${trashed.id}?trash=true&draft=true`, { deletedAt: null });
console.log(`draft save that clears deletedAt on the latest version: REST ${draftSave.status}`);
await step("no-trash member, live edit of a page whose main row is in the trash", () =>
  as(payload, partial).update({ collection: "pages", data: { _status: "published", title: "live now" }, id: trashed.id }),
);
const after = await payload.db.findOne({ collection: "pages", where: { id: { equals: trashed.id } } });
console.log(`    main row after: deletedAt=${JSON.stringify(after.deletedAt)} title=${JSON.stringify(after.title)}`);

await payload.updateGlobal({ data: { _status: "draft", siteName: "draft" }, slug: "settings" });
await step("no-unpublish member, non-draft edit of the draft settings global", () =>
  as(payload, partial).updateGlobal({ data: { siteName: "edited" }, slug: "settings" }),
);

await payload.updateGlobal({ data: { _status: "published", siteName: "old" }, slug: "settings" });
await payload.updateGlobal({ data: { _status: "published", siteName: "new" }, slug: "settings" });
const { docs } = await payload.findGlobalVersions({ depth: 0, limit: 1, slug: "settings", where: { "version.siteName": { equals: "old" } } });
const restore = (user, id) => payload.restoreGlobalVersion({ id: String(id), overrideAccess: false, slug: "settings", user });
await step("full member, global restore", () => restore(full, docs[0].id));
await step("full member, global restore of a missing version", () => restore(full, docs[0].id + 1000));
await step("no-unpublish member, global restore", () => restore(partial, docs[0].id));
await step("no-unpublish member, global restore of a missing version", () => restore(partial, docs[0].id + 1000));

await context.destroy();
