// Compares groups of perf.bench.ts runs: node agg.mjs <label>=<file-prefix> [<label>=<file-prefix>]
// A prefix matches every runs/<prefix>*.json. With two groups the second is compared with the first.
import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";

const groups = process.argv.slice(2).map((arg) => {
  const [label, prefix] = arg.split("=");
  const dir = path.dirname(prefix);
  const base = path.basename(prefix);
  const files = readdirSync(dir)
    .filter((name) => name.startsWith(base) && name.endsWith(".json"))
    .toSorted()
    .map((name) => path.join(dir, name));
  return { label, files, runs: files.map((file) => JSON.parse(readFileSync(file, "utf8"))) };
});

const SIDES = ["member", "memberPartial", "memberWarm", "superAdmin", "trusted"];
const med = (xs) => {
  const s = xs.toSorted((a, b) => a - b);
  return s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
};
const f3 = (x) => (Number.isFinite(x) ? x.toFixed(3) : "-");
const range = (xs) => `${f3(Math.min(...xs))}..${f3(Math.max(...xs))}`;

for (const { label, files, runs } of groups) {
  console.log(`## ${label}: ${runs.length} runs`);
  for (const [index, run] of runs.entries()) {
    const m = run.meta;
    console.log(
      `- ${path.basename(files[index])}: ${m.timestamp} head ${m.gitHead?.slice(0, 7)} ${m.cpu} ${m.cores} cores, Node ${m.node}, Payload ${m.payload}, load ${m.loadAvgStart[0]} -> ${m.loadAvgEnd[0]}, wall ${m.wallSeconds}s, pages ${run.dataset.pagesAtStart}/${run.dataset.pagesAfterTiming}/${run.dataset.pagesAtEnd}, versions ${run.dataset.pageVersionsAtEnd}, iterations ${m.config.iterations}`,
    );
  }
  let errors = 0;
  for (const run of runs) {
    for (const part of [run.timing, run.counts]) {
      for (const op of Object.values(part)) {
        for (const side of Object.values(op)) {
          errors += side.errors;
        }
      }
    }
  }
  console.log(`- errors across all runs, timing and counting: ${errors}\n`);
}

const ops = Object.keys(groups[0].runs[0].timing);
const stat = (group, op, side, key) =>
  group.runs.map((run) => run.timing[op]?.[side]?.[key]).filter((value) => value !== undefined);

const [a, b] = groups;
console.log("## medians (median of run medians, [range of run medians]) and p95, ms\n");
console.log(
  b
    ? `| op | side | ${a.label} median [range] | ${a.label} p95 | ${b.label} median [range] | ${b.label} p95 | delta ms | delta % | ranges overlap |`
    : `| op | side | median [range] | spread | p95 (median) [range] |`,
);
console.log(b ? "|---|---|---|---|---|---|---|---|---|" : "|---|---|---|---|---|");
for (const op of ops) {
  for (const side of SIDES) {
    const am = stat(a, op, side, "medianMs");
    if (am.length === 0) {
      continue;
    }
    const ap = stat(a, op, side, "p95Ms");
    if (!b) {
      const spread = ((Math.max(...am) - Math.min(...am)) / med(am)) * 100;
      console.log(
        `| ${op} | ${side} | ${f3(med(am))} [${range(am)}] | ${spread.toFixed(1)}% | ${f3(med(ap))} [${range(ap)}] |`,
      );
      continue;
    }
    const bm = stat(b, op, side, "medianMs");
    const bp = stat(b, op, side, "p95Ms");
    const delta = med(bm) - med(am);
    const overlap = Math.max(...bm) >= Math.min(...am) && Math.max(...am) >= Math.min(...bm);
    console.log(
      `| ${op} | ${side} | ${f3(med(am))} [${range(am)}] | ${f3(med(ap))} | ${f3(med(bm))} [${range(bm)}] | ${f3(med(bp))} | ${delta >= 0 ? "+" : ""}${f3(delta)} | ${((delta / med(am)) * 100).toFixed(1)}% | ${overlap ? "yes" : "NO"} |`,
    );
  }
}

// Sides alternate inside one iteration, so a side's median minus the trusted median of the same
// run cancels most machine noise. REST ops have no trusted side; superAdmin is their floor.
console.log("\n## paired overhead per run: side median - floor median of the same run, ms\n");
console.log(
  `| op | side - floor | ${groups.map((g) => `${g.label} median [range]`).join(" | ")} |${b ? " delta ms | ranges overlap |" : ""}`,
);
console.log(`|---|---|${groups.map(() => "---|").join("")}${b ? "---|---|" : ""}`);
const paired = (group, op, side, floor) =>
  group.runs
    .filter((run) => run.timing[op]?.[side] && run.timing[op]?.[floor])
    .map((run) => run.timing[op][side].medianMs - run.timing[op][floor].medianMs);
for (const op of ops) {
  const floor = a.runs[0].timing[op].trusted ? "trusted" : "superAdmin";
  for (const side of SIDES) {
    if (side === floor || !a.runs[0].timing[op][side]) {
      continue;
    }
    const per = groups.map((group) => paired(group, op, side, floor));
    const cells = per.map((xs) => `${f3(med(xs))} [${range(xs)}]`).join(" | ");
    let tail = "";
    if (b) {
      const [x, y] = per;
      const overlap = Math.max(...y) >= Math.min(...x) && Math.max(...x) >= Math.min(...y);
      const delta = med(y) - med(x);
      tail = ` ${delta >= 0 ? "+" : ""}${f3(delta)} | ${overlap ? "yes" : "NO"} |`;
    }
    console.log(`| ${op} | ${side} - ${floor} | ${cells} |${tail}`);
  }
}

const fmt = (value) => (typeof value === "number" ? String(value) : `${value.min}..${value.max}`);
const countsOf = (run, op, side) =>
  Object.entries(run.counts[op]?.[side]?.counts ?? {}).filter(([key]) => !key.includes(" <- "));
const countLine = (run, op, side) =>
  countsOf(run, op, side)
    .filter(([key]) => !/Transaction/u.test(key))
    .map(([key, value]) => `${key.replace(/^db\./u, "")}=${fmt(value)}`)
    .join(", ");
const dbTotal = (run, op, side) =>
  countsOf(run, op, side)
    .filter(([key]) => key.startsWith("db.") && !/Transaction/u.test(key))
    .reduce((sum, [, value]) => sum + (typeof value === "number" ? value : value.max), 0);

console.log("\n## calls per op (counting pass)\n");
for (const group of groups) {
  let same = true;
  for (const op of ops) {
    for (const side of SIDES) {
      const lines = group.runs.map((run) => countLine(run, op, side));
      if (!lines.every((line) => line === lines[0])) {
        same = false;
        console.log(`- ${group.label}: ${op} ${side} differs across runs: ${[...new Set(lines)].join(" || ")}`);
      }
    }
  }
  console.log(`- ${group.label}: counts ${same ? "identical in every run" : "differ as listed"}`);
}
console.log(
  `\n| op | side | ${groups.map((g) => `${g.label} db calls`).join(" | ")} | ${groups.map((g) => `${g.label} calls`).join(" | ")} |`,
);
console.log(`|---|---|${groups.map(() => "---|---|").join("")}`);
for (const op of ops) {
  for (const side of SIDES) {
    if (!a.runs[0].counts[op]?.[side]) {
      continue;
    }
    const totals = groups.map((group) => dbTotal(group.runs[0], op, side));
    const lines = groups.map((group) => countLine(group.runs[0], op, side));
    const changed = b && lines[0] !== lines[1] ? " **" : "";
    console.log(`| ${op} | ${side}${changed} | ${totals.join(" | ")} | ${lines.join(" | ")} |`);
  }
}

console.log("\n## plugin-originated calls (first run of each group)\n");
for (const group of groups) {
  console.log(`### ${group.label}`);
  for (const op of ops) {
    for (const side of SIDES) {
      const entry = group.runs[0].counts[op]?.[side];
      if (!entry) {
        continue;
      }
      const own = Object.entries(entry.counts).filter(([key]) => key.includes(" <- roles:"));
      if (own.length > 0) {
        console.log(`- ${op} ${side}: ${own.map(([key, value]) => `${key}=${fmt(value)}`).join(", ")}`);
      }
    }
  }
}
