import { pathToFileURL } from "node:url";
const { createTestPayload } = await import(pathToFileURL(`${process.cwd()}/tests/helpers/payload.ts`));
const context = await createTestPayload({ name: "select-check" });
const { payload } = context;
const page = await payload.create({ collection: "pages", data: { _status: "published", title: "x" } });
const where = { id: { equals: page.id } };
const session = payload.db.drizzle.session ?? payload.db.drizzle._.session;
const client = payload.db.client;
const original = client.execute.bind(client);
client.execute = (query) => { console.log("  SQL:", typeof query === "string" ? query : query.sql); return original(query); };
for (const select of [undefined, { _status: true, deletedAt: true }]) {
  console.log("select", JSON.stringify(select));
  const row = await payload.db.findOne({ collection: "pages", select, where });
  console.log("  keys", Object.keys(row));
}
console.log("global select");
console.log("  keys", Object.keys(await payload.db.findGlobal({ slug: "settings", select: { _status: true } })));
await context.destroy();
