# Applies the opt-in BENCH_WIDE fixture to perf.bench.ts. Run from packages/payload-roles.
p='tests/integration/lifecycle/perf.bench.ts'
s=open(p).read()
def rep(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a))
    s=s.replace(a,b)
rep('''//      BENCH_BASE_PAGES (1000), BENCH_BULK (20), BENCH_OPS (comma-separated op names; all).
''','''//      BENCH_BASE_PAGES (1000), BENCH_BULK (20), BENCH_OPS (comma-separated op names; all),
//      BENCH_WIDE (1 gives every page an array, a relationship and a text list; off).
''')
rep('''import type { Payload } from "payload";
''','''import type { CollectionConfig, Payload } from "payload";
''')
rep('''import { createTestPayload, defaultRolesOptions } from "../../helpers/payload.ts";''','''import {
  createTestPayload,
  defaultRolesOptions,
  fixtureCollections,
} from "../../helpers/payload.ts";''')
rep('''const ONLY_OPS = process.env.BENCH_OPS?.split(",").filter(Boolean);
''','''const ONLY_OPS = process.env.BENCH_OPS?.split(",").filter(Boolean);
const WIDE = process.env.BENCH_WIDE === "1";
''')
rep('''const context = await createTestPayload({
  name: "lifecycle-perf",
  roles: { ...defaultRolesOptions(), debug: false },
});
const { payload } = context;
''','''/** The fixture page has one text field. A real page also has rows in other tables. */
const widePages = (): CollectionConfig[] =>
  fixtureCollections().map((collection) =>
    collection.slug === "pages"
      ? {
          ...collection,
          fields: [
            ...collection.fields,
            {
              name: "sections",
              type: "array",
              fields: [
                { name: "heading", type: "text" },
                { name: "body", type: "textarea" },
              ],
            },
            { name: "related", type: "relationship", hasMany: true, relationTo: "posts" },
            { name: "tags", type: "text", hasMany: true },
          ],
        }
      : collection,
  );

const context = await createTestPayload({
  name: "lifecycle-perf",
  roles: { ...defaultRolesOptions(), debug: false },
  ...(WIDE && { collections: widePages() }),
});
const { payload } = context;

const wideData = async (): Promise<Row> => {
  const related: Id[] = [];
  for (const title of ["one", "two", "three"]) {
    // oxlint-disable-next-line no-await-in-loop -- three fixture posts
    related.push((await payload.create({ collection: "posts", data: { title } })).id);
  }
  return {
    related,
    sections: Array.from({ length: 5 }, (_unused, index) => ({
      body: `body ${index} `.repeat(40),
      heading: `heading ${index}`,
    })),
    tags: ["alpha", "beta", "gamma"],
  };
};
const pageExtras = WIDE ? await wideData() : {};
''')
rep('''  const page = await payload.create({ collection: "pages", data: { _status: status, title } });''','''  const page = await payload.create({
    collection: "pages",
    data: { ...pageExtras, _status: status, title },
  });''')
rep('''      bulk: BULK,
      rolesDebug: false,''','''      bulk: BULK,
      wide: WIDE,
      rolesDebug: false,''')
open(p,'w').write(s)
