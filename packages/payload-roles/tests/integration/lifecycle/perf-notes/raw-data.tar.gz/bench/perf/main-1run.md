## base: 1 runs
- main-base-run1.json: 2026-11-14T13:00:39.654Z head 002bdf0 Apple M3 8 cores, Node v24.22.2, Payload 3.90.1, load 8.347 -> 10.755, wall 138.429s, pages 1000/3075/3350, versions 27578, iterations 200
- errors across all runs, timing and counting: 0

## gr1: 1 runs
- main-gr1-run1.json: 2026-11-14T13:07:22.505Z head 002bdf0 Apple M3 8 cores, Node v24.22.2, Payload 3.90.1, load 6.2 -> 9.926, wall 113.469s, pages 1000/3075/3350, versions 27578, iterations 200
- errors across all runs, timing and counting: 0

## medians (median of run medians, [range of run medians]) and p95, ms

| op | side | base median [range] | base p95 | gr1 median [range] | gr1 p95 | delta ms | delta % | ranges overlap |
|---|---|---|---|---|---|---|---|---|
| createDraft | member | 0.719 [0.719..0.719] | 1.836 | 0.542 [0.542..0.542] | 0.598 | -0.177 | -24.6% | NO |
| createDraft | memberWarm | 0.579 [0.579..0.579] | 1.398 | 0.432 [0.432..0.432] | 0.483 | -0.147 | -25.4% | NO |
| createDraft | superAdmin | 0.566 [0.566..0.566] | 1.599 | 0.426 [0.426..0.426] | 0.469 | -0.140 | -24.7% | NO |
| createDraft | trusted | 0.544 [0.544..0.544] | 1.568 | 0.424 [0.424..0.424] | 0.482 | -0.120 | -22.1% | NO |
| createPublished | member | 0.566 [0.566..0.566] | 0.925 | 0.510 [0.510..0.510] | 0.585 | -0.056 | -9.9% | NO |
| createPublished | memberWarm | 0.455 [0.455..0.455] | 0.716 | 0.412 [0.412..0.412] | 0.445 | -0.043 | -9.5% | NO |
| createPublished | superAdmin | 0.443 [0.443..0.443] | 0.874 | 0.404 [0.404..0.404] | 0.445 | -0.039 | -8.8% | NO |
| createPublished | trusted | 0.436 [0.436..0.436] | 0.806 | 0.402 [0.402..0.402] | 0.441 | -0.034 | -7.8% | NO |
| updateDraftSave | member | 1.263 [1.263..1.263] | 2.780 | 1.133 [1.133..1.133] | 1.383 | -0.130 | -10.3% | NO |
| updateDraftSave | memberWarm | 1.128 [1.128..1.128] | 2.403 | 1.033 [1.033..1.033] | 1.218 | -0.095 | -8.4% | NO |
| updateDraftSave | superAdmin | 1.125 [1.125..1.125] | 2.309 | 1.023 [1.023..1.023] | 1.230 | -0.102 | -9.1% | NO |
| updateDraftSave | trusted | 1.120 [1.120..1.120] | 2.318 | 1.020 [1.020..1.020] | 1.299 | -0.100 | -8.9% | NO |
| updateLiveEdit | member | 1.311 [1.311..1.311] | 1.968 | 1.313 [1.313..1.313] | 2.296 | +0.002 | 0.2% | NO |
| updateLiveEdit | memberPartial | 1.413 [1.413..1.413] | 2.357 | 1.381 [1.381..1.381] | 2.303 | -0.032 | -2.3% | NO |
| updateLiveEdit | memberWarm | 1.197 [1.197..1.197] | 2.214 | 1.214 [1.214..1.214] | 1.710 | +0.017 | 1.4% | NO |
| updateLiveEdit | superAdmin | 1.183 [1.183..1.183] | 1.985 | 1.188 [1.188..1.188] | 1.916 | +0.005 | 0.4% | NO |
| updateLiveEdit | trusted | 1.178 [1.178..1.178] | 1.763 | 1.179 [1.179..1.179] | 1.709 | +0.001 | 0.1% | NO |
| unpublish | member | 1.338 [1.338..1.338] | 2.401 | 1.661 [1.661..1.661] | 4.636 | +0.323 | 24.1% | NO |
| unpublish | memberWarm | 1.200 [1.200..1.200] | 2.008 | 1.444 [1.444..1.444] | 3.567 | +0.244 | 20.3% | NO |
| unpublish | superAdmin | 1.181 [1.181..1.181] | 1.668 | 1.554 [1.554..1.554] | 3.967 | +0.373 | 31.6% | NO |
| unpublish | trusted | 1.176 [1.176..1.176] | 2.258 | 1.491 [1.491..1.491] | 4.312 | +0.315 | 26.8% | NO |
| moveToTrash | member | 1.259 [1.259..1.259] | 2.088 | 1.733 [1.733..1.733] | 5.487 | +0.474 | 37.6% | NO |
| moveToTrash | memberWarm | 1.135 [1.135..1.135] | 1.674 | 1.508 [1.508..1.508] | 4.193 | +0.373 | 32.9% | NO |
| moveToTrash | superAdmin | 1.110 [1.110..1.110] | 1.808 | 1.524 [1.524..1.524] | 3.802 | +0.414 | 37.3% | NO |
| moveToTrash | trusted | 1.107 [1.107..1.107] | 1.540 | 1.497 [1.497..1.497] | 4.037 | +0.390 | 35.2% | NO |
| restoreFromTrash | member | 1.281 [1.281..1.281] | 4.763 | 1.444 [1.444..1.444] | 3.688 | +0.163 | 12.7% | NO |
| restoreFromTrash | memberWarm | 1.110 [1.110..1.110] | 3.690 | 1.305 [1.305..1.305] | 3.098 | +0.195 | 17.6% | NO |
| restoreFromTrash | superAdmin | 1.093 [1.093..1.093] | 3.454 | 1.285 [1.285..1.285] | 2.894 | +0.192 | 17.6% | NO |
| restoreFromTrash | trusted | 1.088 [1.088..1.088] | 3.554 | 1.244 [1.244..1.244] | 2.902 | +0.156 | 14.3% | NO |
| restoreVersion | member | 2.326 [2.326..2.326] | 13.649 | 1.287 [1.287..1.287] | 2.122 | -1.039 | -44.7% | NO |
| restoreVersion | memberWarm | 2.079 [2.079..2.079] | 9.781 | 1.162 [1.162..1.162] | 2.146 | -0.917 | -44.1% | NO |
| restoreVersion | superAdmin | 2.229 [2.229..2.229] | 12.127 | 1.152 [1.152..1.152] | 2.143 | -1.077 | -48.3% | NO |
| restoreVersion | trusted | 1.966 [1.966..1.966] | 12.253 | 1.130 [1.130..1.130] | 2.227 | -0.836 | -42.5% | NO |
| deletePermanent | member | 0.923 [0.923..0.923] | 3.132 | 0.728 [0.728..0.728] | 1.048 | -0.195 | -21.1% | NO |
| deletePermanent | memberWarm | 0.749 [0.749..0.749] | 2.694 | 0.611 [0.611..0.611] | 0.862 | -0.138 | -18.4% | NO |
| deletePermanent | superAdmin | 0.743 [0.743..0.743] | 2.491 | 0.617 [0.617..0.617] | 0.803 | -0.126 | -17.0% | NO |
| deletePermanent | trusted | 0.763 [0.763..0.763] | 2.695 | 0.606 [0.606..0.606] | 0.775 | -0.157 | -20.6% | NO |
| bulkUpdate20 | member | 22.608 [22.608..22.608] | 80.673 | 23.760 [23.760..23.760] | 83.663 | +1.152 | 5.1% | NO |
| bulkUpdate20 | memberPartial | 24.960 [24.960..24.960] | 114.912 | 25.424 [25.424..25.424] | 78.852 | +0.464 | 1.9% | NO |
| bulkUpdate20 | memberWarm | 22.279 [22.279..22.279] | 95.938 | 23.202 [23.202..23.202] | 81.807 | +0.923 | 4.1% | NO |
| bulkUpdate20 | superAdmin | 22.684 [22.684..22.684] | 100.218 | 23.801 [23.801..23.801] | 66.606 | +1.117 | 4.9% | NO |
| bulkUpdate20 | trusted | 22.827 [22.827..22.827] | 89.921 | 23.402 [23.402..23.402] | 71.617 | +0.575 | 2.5% | NO |
| restLiveEdit | member | 2.500 [2.500..2.500] | 5.279 | 2.208 [2.208..2.208] | 4.393 | -0.292 | -11.7% | NO |
| restLiveEdit | superAdmin | 2.267 [2.267..2.267] | 4.638 | 2.062 [2.062..2.062] | 4.063 | -0.205 | -9.0% | NO |
| editDraft | member | 1.909 [1.909..1.909] | 5.648 | 1.577 [1.577..1.577] | 3.785 | -0.332 | -17.4% | NO |
| editDraft | memberPartial | 1.999 [1.999..1.999] | 6.849 | 1.672 [1.672..1.672] | 4.040 | -0.327 | -16.4% | NO |
| editDraft | memberWarm | 1.838 [1.838..1.838] | 6.373 | 1.475 [1.475..1.475] | 4.013 | -0.363 | -19.7% | NO |
| editDraft | superAdmin | 1.736 [1.736..1.736] | 5.791 | 1.421 [1.421..1.421] | 4.096 | -0.315 | -18.1% | NO |
| editDraft | trusted | 1.732 [1.732..1.732] | 5.345 | 1.419 [1.419..1.419] | 4.152 | -0.313 | -18.1% | NO |
| bulkEditDraft20 | member | 27.743 [27.743..27.743] | 74.307 | 24.587 [24.587..24.587] | 69.307 | -3.156 | -11.4% | NO |
| bulkEditDraft20 | memberPartial | 30.521 [30.521..30.521] | 96.940 | 25.590 [25.590..25.590] | 58.592 | -4.931 | -16.2% | NO |
| bulkEditDraft20 | memberWarm | 27.846 [27.846..27.846] | 93.684 | 25.227 [25.227..25.227] | 69.034 | -2.619 | -9.4% | NO |
| bulkEditDraft20 | superAdmin | 28.360 [28.360..28.360] | 76.272 | 23.771 [23.771..23.771] | 70.639 | -4.589 | -16.2% | NO |
| bulkEditDraft20 | trusted | 27.253 [27.253..27.253] | 95.522 | 23.632 [23.632..23.632] | 65.564 | -3.621 | -13.3% | NO |
| probeDocAccess | member | 0.462 [0.462..0.462] | 1.669 | 0.495 [0.495..0.495] | 1.982 | +0.033 | 7.1% | NO |
| probeDocAccess | memberPartial | 0.469 [0.469..0.469] | 1.520 | 0.499 [0.499..0.499] | 1.862 | +0.030 | 6.4% | NO |
| probeDocAccess | superAdmin | 0.351 [0.351..0.351] | 1.532 | 0.370 [0.370..0.370] | 1.426 | +0.019 | 5.4% | NO |
| probeAccess | member | 0.514 [0.514..0.514] | 0.727 | 0.541 [0.541..0.541] | 0.862 | +0.027 | 5.3% | NO |
| probeAccess | memberPartial | 0.516 [0.516..0.516] | 0.609 | 0.545 [0.545..0.545] | 0.804 | +0.029 | 5.6% | NO |
| probeAccess | superAdmin | 0.394 [0.394..0.394] | 0.488 | 0.417 [0.417..0.417] | 0.569 | +0.023 | 5.8% | NO |
| globalUpdate | member | 0.960 [0.960..0.960] | 1.431 | 1.162 [1.162..1.162] | 5.481 | +0.202 | 21.0% | NO |
| globalUpdate | memberPartial | 0.963 [0.963..0.963] | 1.325 | 1.151 [1.151..1.151] | 4.772 | +0.188 | 19.5% | NO |
| globalUpdate | memberWarm | 0.861 [0.861..0.861] | 1.111 | 1.061 [1.061..1.061] | 4.544 | +0.200 | 23.2% | NO |
| globalUpdate | superAdmin | 0.849 [0.849..0.849] | 1.122 | 1.012 [1.012..1.012] | 3.983 | +0.163 | 19.2% | NO |
| globalUpdate | trusted | 0.846 [0.846..0.846] | 1.217 | 0.980 [0.980..0.980] | 3.892 | +0.134 | 15.8% | NO |
| globalEditDraft | member | 1.048 [1.048..1.048] | 2.627 | 1.288 [1.288..1.288] | 5.206 | +0.240 | 22.9% | NO |
| globalEditDraft | memberPartial | 1.137 [1.137..1.137] | 3.042 | 1.346 [1.346..1.346] | 4.811 | +0.209 | 18.4% | NO |
| globalEditDraft | memberWarm | 0.933 [0.933..0.933] | 2.284 | 1.094 [1.094..1.094] | 4.164 | +0.161 | 17.3% | NO |
| globalEditDraft | superAdmin | 0.913 [0.913..0.913] | 2.075 | 1.102 [1.102..1.102] | 4.203 | +0.189 | 20.7% | NO |
| globalEditDraft | trusted | 0.905 [0.905..0.905] | 1.394 | 1.114 [1.114..1.114] | 4.219 | +0.209 | 23.1% | NO |
| globalRestore | member | 1.436 [1.436..1.436] | 6.979 | 0.965 [0.965..0.965] | 3.195 | -0.471 | -32.8% | NO |
| globalRestore | memberPartial | 1.406 [1.406..1.406] | 7.861 | 1.182 [1.182..1.182] | 3.834 | -0.224 | -15.9% | NO |
| globalRestore | memberWarm | 1.178 [1.178..1.178] | 4.172 | 0.836 [0.836..0.836] | 2.242 | -0.342 | -29.0% | NO |
| globalRestore | superAdmin | 0.893 [0.893..0.893] | 2.968 | 0.797 [0.797..0.797] | 2.184 | -0.096 | -10.8% | NO |
| globalRestore | trusted | 0.836 [0.836..0.836] | 4.808 | 0.792 [0.792..0.792] | 2.300 | -0.044 | -5.3% | NO |

## paired overhead per run: side median - floor median of the same run, ms

| op | side - floor | base median [range] | gr1 median [range] | delta ms | ranges overlap |
|---|---|---|---|---|---|
| createDraft | member - trusted | 0.175 [0.175..0.175] | 0.118 [0.118..0.118] | -0.057 | NO |
| createDraft | memberWarm - trusted | 0.035 [0.035..0.035] | 0.008 [0.008..0.008] | -0.027 | NO |
| createDraft | superAdmin - trusted | 0.022 [0.022..0.022] | 0.002 [0.002..0.002] | -0.020 | NO |
| createPublished | member - trusted | 0.130 [0.130..0.130] | 0.108 [0.108..0.108] | -0.022 | NO |
| createPublished | memberWarm - trusted | 0.019 [0.019..0.019] | 0.010 [0.010..0.010] | -0.009 | NO |
| createPublished | superAdmin - trusted | 0.007 [0.007..0.007] | 0.002 [0.002..0.002] | -0.005 | NO |
| updateDraftSave | member - trusted | 0.143 [0.143..0.143] | 0.113 [0.113..0.113] | -0.030 | NO |
| updateDraftSave | memberWarm - trusted | 0.008 [0.008..0.008] | 0.013 [0.013..0.013] | +0.005 | NO |
| updateDraftSave | superAdmin - trusted | 0.005 [0.005..0.005] | 0.003 [0.003..0.003] | -0.002 | NO |
| updateLiveEdit | member - trusted | 0.133 [0.133..0.133] | 0.134 [0.134..0.134] | +0.001 | NO |
| updateLiveEdit | memberPartial - trusted | 0.235 [0.235..0.235] | 0.202 [0.202..0.202] | -0.033 | NO |
| updateLiveEdit | memberWarm - trusted | 0.019 [0.019..0.019] | 0.035 [0.035..0.035] | +0.016 | NO |
| updateLiveEdit | superAdmin - trusted | 0.005 [0.005..0.005] | 0.009 [0.009..0.009] | +0.004 | NO |
| unpublish | member - trusted | 0.162 [0.162..0.162] | 0.170 [0.170..0.170] | +0.008 | NO |
| unpublish | memberWarm - trusted | 0.024 [0.024..0.024] | -0.047 [-0.047..-0.047] | -0.071 | NO |
| unpublish | superAdmin - trusted | 0.005 [0.005..0.005] | 0.063 [0.063..0.063] | +0.058 | NO |
| moveToTrash | member - trusted | 0.152 [0.152..0.152] | 0.236 [0.236..0.236] | +0.084 | NO |
| moveToTrash | memberWarm - trusted | 0.028 [0.028..0.028] | 0.011 [0.011..0.011] | -0.017 | NO |
| moveToTrash | superAdmin - trusted | 0.003 [0.003..0.003] | 0.027 [0.027..0.027] | +0.024 | NO |
| restoreFromTrash | member - trusted | 0.193 [0.193..0.193] | 0.200 [0.200..0.200] | +0.007 | NO |
| restoreFromTrash | memberWarm - trusted | 0.022 [0.022..0.022] | 0.061 [0.061..0.061] | +0.039 | NO |
| restoreFromTrash | superAdmin - trusted | 0.005 [0.005..0.005] | 0.041 [0.041..0.041] | +0.036 | NO |
| restoreVersion | member - trusted | 0.360 [0.360..0.360] | 0.157 [0.157..0.157] | -0.203 | NO |
| restoreVersion | memberWarm - trusted | 0.113 [0.113..0.113] | 0.032 [0.032..0.032] | -0.081 | NO |
| restoreVersion | superAdmin - trusted | 0.263 [0.263..0.263] | 0.022 [0.022..0.022] | -0.241 | NO |
| deletePermanent | member - trusted | 0.160 [0.160..0.160] | 0.122 [0.122..0.122] | -0.038 | NO |
| deletePermanent | memberWarm - trusted | -0.014 [-0.014..-0.014] | 0.005 [0.005..0.005] | +0.019 | NO |
| deletePermanent | superAdmin - trusted | -0.020 [-0.020..-0.020] | 0.011 [0.011..0.011] | +0.031 | NO |
| bulkUpdate20 | member - trusted | -0.219 [-0.219..-0.219] | 0.358 [0.358..0.358] | +0.577 | NO |
| bulkUpdate20 | memberPartial - trusted | 2.133 [2.133..2.133] | 2.022 [2.022..2.022] | -0.111 | NO |
| bulkUpdate20 | memberWarm - trusted | -0.548 [-0.548..-0.548] | -0.200 [-0.200..-0.200] | +0.348 | NO |
| bulkUpdate20 | superAdmin - trusted | -0.143 [-0.143..-0.143] | 0.399 [0.399..0.399] | +0.542 | NO |
| restLiveEdit | member - superAdmin | 0.233 [0.233..0.233] | 0.146 [0.146..0.146] | -0.087 | NO |
| editDraft | member - trusted | 0.177 [0.177..0.177] | 0.158 [0.158..0.158] | -0.019 | NO |
| editDraft | memberPartial - trusted | 0.267 [0.267..0.267] | 0.253 [0.253..0.253] | -0.014 | NO |
| editDraft | memberWarm - trusted | 0.106 [0.106..0.106] | 0.056 [0.056..0.056] | -0.050 | NO |
| editDraft | superAdmin - trusted | 0.004 [0.004..0.004] | 0.002 [0.002..0.002] | -0.002 | NO |
| bulkEditDraft20 | member - trusted | 0.490 [0.490..0.490] | 0.955 [0.955..0.955] | +0.465 | NO |
| bulkEditDraft20 | memberPartial - trusted | 3.268 [3.268..3.268] | 1.958 [1.958..1.958] | -1.310 | NO |
| bulkEditDraft20 | memberWarm - trusted | 0.593 [0.593..0.593] | 1.595 [1.595..1.595] | +1.002 | NO |
| bulkEditDraft20 | superAdmin - trusted | 1.107 [1.107..1.107] | 0.139 [0.139..0.139] | -0.968 | NO |
| probeDocAccess | member - superAdmin | 0.111 [0.111..0.111] | 0.125 [0.125..0.125] | +0.014 | NO |
| probeDocAccess | memberPartial - superAdmin | 0.118 [0.118..0.118] | 0.129 [0.129..0.129] | +0.011 | NO |
| probeAccess | member - superAdmin | 0.120 [0.120..0.120] | 0.124 [0.124..0.124] | +0.004 | NO |
| probeAccess | memberPartial - superAdmin | 0.122 [0.122..0.122] | 0.128 [0.128..0.128] | +0.006 | NO |
| globalUpdate | member - trusted | 0.114 [0.114..0.114] | 0.182 [0.182..0.182] | +0.068 | NO |
| globalUpdate | memberPartial - trusted | 0.117 [0.117..0.117] | 0.171 [0.171..0.171] | +0.054 | NO |
| globalUpdate | memberWarm - trusted | 0.015 [0.015..0.015] | 0.081 [0.081..0.081] | +0.066 | NO |
| globalUpdate | superAdmin - trusted | 0.003 [0.003..0.003] | 0.032 [0.032..0.032] | +0.029 | NO |
| globalEditDraft | member - trusted | 0.143 [0.143..0.143] | 0.174 [0.174..0.174] | +0.031 | NO |
| globalEditDraft | memberPartial - trusted | 0.232 [0.232..0.232] | 0.232 [0.232..0.232] | +0.000 | yes |
| globalEditDraft | memberWarm - trusted | 0.028 [0.028..0.028] | -0.020 [-0.020..-0.020] | -0.048 | NO |
| globalEditDraft | superAdmin - trusted | 0.008 [0.008..0.008] | -0.012 [-0.012..-0.012] | -0.020 | NO |
| globalRestore | member - trusted | 0.600 [0.600..0.600] | 0.173 [0.173..0.173] | -0.427 | NO |
| globalRestore | memberPartial - trusted | 0.570 [0.570..0.570] | 0.390 [0.390..0.390] | -0.180 | NO |
| globalRestore | memberWarm - trusted | 0.342 [0.342..0.342] | 0.044 [0.044..0.044] | -0.298 | NO |
| globalRestore | superAdmin - trusted | 0.057 [0.057..0.057] | 0.005 [0.005..0.005] | -0.052 | NO |

## calls per op (counting pass)

- base: counts identical in every run
- gr1: counts identical in every run

| op | side | base db calls | gr1 db calls | base calls | gr1 calls |
|---|---|---|---|---|---|
| createDraft | member | 4 | 4 | create pages=1, createVersion pages=1, find roles=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, find roles=1, findVersions pages=1, subject=2 |
| createDraft | memberWarm | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 |
| createDraft | superAdmin | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 |
| createDraft | trusted | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1 | create pages=1, createVersion pages=1, findVersions pages=1 |
| createPublished | member | 4 | 4 | create pages=1, createVersion pages=1, find roles=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, find roles=1, findVersions pages=1, subject=2 |
| createPublished | memberWarm | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 |
| createPublished | superAdmin | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 | create pages=1, createVersion pages=1, findVersions pages=1, subject=2 |
| createPublished | trusted | 3 | 3 | create pages=1, createVersion pages=1, findVersions pages=1 | create pages=1, createVersion pages=1, findVersions pages=1 |
| updateDraftSave | member | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, subject=2 |
| updateDraftSave | memberWarm | 4 | 4 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, subject=2 |
| updateDraftSave | superAdmin | 4 | 4 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, subject=2 |
| updateDraftSave | trusted | 4 | 4 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2 |
| updateLiveEdit | member | 6 | 6 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 |
| updateLiveEdit | memberPartial | 7 | 7 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findOne pages=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findOne pages=1, findVersions pages=2, updateOne pages=1, subject=2 |
| updateLiveEdit | memberWarm | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| updateLiveEdit | superAdmin | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| updateLiveEdit | trusted | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 |
| unpublish | member | 6 | 6 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 |
| unpublish | memberWarm | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| unpublish | superAdmin | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| unpublish | trusted | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 |
| moveToTrash | member | 6 | 6 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=3 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=3 |
| moveToTrash | memberWarm | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=3 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=3 |
| moveToTrash | superAdmin | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=3 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=3 |
| moveToTrash | trusted | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 |
| restoreFromTrash | member | 6 | 6 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, find roles=1, findVersions pages=1, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, find roles=1, findVersions pages=1, updateOne pages=1, subject=2 |
| restoreFromTrash | memberWarm | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1, subject=2 |
| restoreFromTrash | superAdmin | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1, subject=2 |
| restoreFromTrash | trusted | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1 | createVersion pages=1, deleteMany payload-locked-documents=1, find pages=1, findVersions pages=1, updateOne pages=1 |
| restoreVersion | member | 7 | 7 | createVersion pages=1, find roles=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 | createVersion pages=1, find roles=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 |
| restoreVersion | memberWarm | 6 | 6 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 |
| restoreVersion | superAdmin | 6 | 6 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1, subject=2 |
| restoreVersion | trusted | 6 | 6 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1 | createVersion pages=1, findOne pages=1, findVersions pages=3, updateOne pages=1 |
| deletePermanent | member | 6 | 6 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, find roles=1, findOne pages=1, subject=1 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, find roles=1, findOne pages=1, subject=1 |
| deletePermanent | memberWarm | 5 | 5 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1, subject=1 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1, subject=1 |
| deletePermanent | superAdmin | 5 | 5 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1, subject=1 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1, subject=1 |
| deletePermanent | trusted | 5 | 5 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1 | deleteMany payload-locked-documents=1, deleteMany payload-preferences=1, deleteOne pages=1, deleteVersions pages=1, findOne pages=1 |
| bulkUpdate20 | member | 82 | 82 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkUpdate20 | memberPartial | 102 | 102 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findOne pages=20, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findOne pages=20, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkUpdate20 | memberWarm | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkUpdate20 | superAdmin | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkUpdate20 | trusted | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20 |
| restLiveEdit | member | 8 | 8 | createVersion pages=1, deleteMany payload-locked-documents=1, find payload-locked-documents=1, find roles=1, findOne users=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find payload-locked-documents=1, find roles=1, findOne users=1, findVersions pages=2, updateOne pages=1, subject=2 |
| restLiveEdit | superAdmin | 7 | 7 | createVersion pages=1, deleteMany payload-locked-documents=1, find payload-locked-documents=1, findOne users=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find payload-locked-documents=1, findOne users=1, findVersions pages=2, updateOne pages=1, subject=2 |
| editDraft | member | 6 | 6 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findVersions pages=2, updateOne pages=1, subject=2 |
| editDraft | memberPartial | 7 | 7 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findOne pages=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, find roles=1, findOne pages=1, findVersions pages=2, updateOne pages=1, subject=2 |
| editDraft | memberWarm | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| editDraft | superAdmin | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1, subject=2 |
| editDraft | trusted | 5 | 5 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 | createVersion pages=1, deleteMany payload-locked-documents=1, findVersions pages=2, updateOne pages=1 |
| bulkEditDraft20 | member | 82 | 82 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkEditDraft20 | memberPartial | 102 | 102 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findOne pages=20, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, find roles=1, findOne pages=20, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkEditDraft20 | memberWarm | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkEditDraft20 | superAdmin | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20, subject=2 |
| bulkEditDraft20 | trusted | 81 | 81 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20 | createVersion pages=20, deleteMany payload-locked-documents=20, find pages=1, findVersions pages=20, updateOne pages=20 |
| probeDocAccess | member | 2 | 2 | find roles=1, findOne users=1, subject=5 | find roles=1, findOne users=1, subject=5 |
| probeDocAccess | memberPartial | 2 | 2 | find roles=1, findOne users=1, subject=5 | find roles=1, findOne users=1, subject=5 |
| probeDocAccess | superAdmin | 1 | 1 | findOne users=1, subject=5 | findOne users=1, subject=5 |
| probeAccess | member | 2 | 2 | find roles=1, findOne users=1, subject=30 | find roles=1, findOne users=1, subject=30 |
| probeAccess | memberPartial | 2 | 2 | find roles=1, findOne users=1, subject=30 | find roles=1, findOne users=1, subject=30 |
| probeAccess | superAdmin | 1 | 1 | findOne users=1, subject=30 | findOne users=1, subject=30 |
| globalUpdate | member | 8 | 8 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalUpdate | memberPartial | 8 | 8 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalUpdate | memberWarm | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalUpdate | superAdmin ** | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=0..1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalUpdate | trusted | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1 |
| globalEditDraft | member | 8 | 8 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalEditDraft | memberPartial | 9 | 9 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=2, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, find roles=1, findGlobal settings=2, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalEditDraft | memberWarm | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalEditDraft | superAdmin ** | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=0..1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1, subject=2 |
| globalEditDraft | trusted | 7 | 7 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1 | createGlobalVersion settings=1, deleteMany payload-locked-documents=1, deleteVersions settings=1, findGlobal settings=1, findGlobalVersions settings=2, updateGlobal settings=1 |
| globalRestore | member ** | 8 | 6 | createGlobalVersion settings=1, find roles=1, findGlobal settings=3, findGlobalVersions settings=2, updateGlobal settings=1, subject=4 | createGlobalVersion settings=1, find roles=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1, subject=3 |
| globalRestore | memberPartial | 8 | 8 | createGlobalVersion settings=1, find roles=1, findGlobal settings=3, findGlobalVersions settings=2, updateGlobal settings=1, subject=4 | createGlobalVersion settings=1, find roles=1, findGlobal settings=3, findGlobalVersions settings=2, updateGlobal settings=1, subject=4 |
| globalRestore | memberWarm ** | 7 | 5 | createGlobalVersion settings=1, findGlobal settings=3, findGlobalVersions settings=2, updateGlobal settings=1, subject=4 | createGlobalVersion settings=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1, subject=3 |
| globalRestore | superAdmin | 5 | 5 | createGlobalVersion settings=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1, subject=3 | createGlobalVersion settings=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1, subject=3 |
| globalRestore | trusted | 5 | 5 | createGlobalVersion settings=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1 | createGlobalVersion settings=1, findGlobal settings=2, findGlobalVersions settings=1, updateGlobal settings=1 |

## plugin-originated calls (first run of each group)

### base
- createDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- moveToTrash member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=2
- moveToTrash memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=2
- moveToTrash superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=2
- restoreFromTrash member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreFromTrash memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreFromTrash superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- deletePermanent member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=1
- deletePermanent memberWarm: subject <- roles:wrapAccess=1
- deletePermanent superAdmin: subject <- roles:wrapAccess=1
- bulkUpdate20 member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=20, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restLiveEdit member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restLiveEdit superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=20, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- probeDocAccess member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=5
- probeDocAccess memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=5
- probeDocAccess superAdmin: subject <- roles:wrapAccess=5
- probeAccess member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- probeAccess memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- probeAccess superAdmin: subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- globalUpdate member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findGlobal settings <- roles:globalHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalRestore member: db.find roles <- roles:loadRoleGrants=1, db.findGlobal settings <- roles:settleGlobalRestore=1, db.findGlobalVersions settings <- roles:settleGlobalRestore=1, subject <- roles:plan=1, subject <- roles:wrapAccess=3
- globalRestore memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findGlobal settings <- roles:settleGlobalRestore=1, db.findGlobalVersions settings <- roles:settleGlobalRestore=1, subject <- roles:plan=1, subject <- roles:wrapAccess=3
- globalRestore memberWarm: db.findGlobal settings <- roles:settleGlobalRestore=1, db.findGlobalVersions settings <- roles:settleGlobalRestore=1, subject <- roles:plan=1, subject <- roles:wrapAccess=3
- globalRestore superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=2
### gr1
- createDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- createPublished superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateDraftSave superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- updateLiveEdit superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- unpublish superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- moveToTrash member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=2
- moveToTrash memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=2
- moveToTrash superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=2
- restoreFromTrash member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreFromTrash memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreFromTrash superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restoreVersion superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- deletePermanent member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=1
- deletePermanent memberWarm: subject <- roles:wrapAccess=1
- deletePermanent superAdmin: subject <- roles:wrapAccess=1
- bulkUpdate20 member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=20, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkUpdate20 superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restLiveEdit member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- restLiveEdit superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- editDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findOne pages <- roles:collectionHooks=20, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- bulkEditDraft20 superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- probeDocAccess member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=5
- probeDocAccess memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:wrapAccess=5
- probeDocAccess superAdmin: subject <- roles:wrapAccess=5
- probeAccess member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- probeAccess memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- probeAccess superAdmin: subject <- roles:createUserFields=4, subject <- roles:wrapAccess=26
- globalUpdate member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate memberPartial: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalUpdate superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findGlobal settings <- roles:globalHooks=1, subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalEditDraft superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=1
- globalRestore member: db.find roles <- roles:loadRoleGrants=1, subject <- roles:plan=1, subject <- roles:wrapAccess=2
- globalRestore memberPartial: db.find roles <- roles:loadRoleGrants=1, db.findGlobal settings <- roles:settleGlobalRestore=1, db.findGlobalVersions settings <- roles:settleGlobalRestore=1, subject <- roles:plan=1, subject <- roles:wrapAccess=3
- globalRestore memberWarm: subject <- roles:plan=1, subject <- roles:wrapAccess=2
- globalRestore superAdmin: subject <- roles:plan=1, subject <- roles:wrapAccess=2
