import { readFileSync, readdirSync } from "node:fs";
const dir = process.argv[2];
const file = readdirSync(dir).find((f) => f.endsWith(".cpuprofile"));
const p = JSON.parse(readFileSync(`${dir}/${file}`, "utf8"));
const byId = new Map(p.nodes.map((n) => [n.id, n]));
const self = new Map();
const dt = p.timeDeltas; let total = 0;
p.samples.forEach((id, i) => { const d = dt[i] ?? 0; total += d; self.set(id, (self.get(id) ?? 0) + d); });
const bucket = (url) => {
  if (!url) return "(native/gc/idle)";
  if (url.includes("payload-roles/dist")) return "payload-roles dist";
  if (url.includes("payload-roles/tests")) return "bench harness + helpers";
  const m = url.match(/node_modules\/(?:\.pnpm\/[^/]+\/node_modules\/)?((?:@[^/]+\/)?[^/]+)/);
  if (m) return m[1];
  if (url.startsWith("node:")) return "node internals";
  return url;
};
const agg = new Map(), fns = new Map();
for (const [id, t] of self) {
  const n = byId.get(id); const b = bucket(n.callFrame.url);
  agg.set(b, (agg.get(b) ?? 0) + t);
  if (b === "payload-roles dist") { const k = `${n.callFrame.functionName || "(anon)"}:${n.callFrame.lineNumber + 1}`; fns.set(k, (fns.get(k) ?? 0) + t); }
}
console.log(`total sampled ${(total / 1e6).toFixed(2)} s`);
for (const [b, t] of [...agg].sort((a, b) => b[1] - a[1]).slice(0, 14)) console.log(`${(t / total * 100).toFixed(1).padStart(5)}%  ${b}`);
console.log("top payload-roles functions (self):");
for (const [k, t] of [...fns].sort((a, b) => b[1] - a[1]).slice(0, 12)) console.log(`${(t / total * 100).toFixed(2).padStart(6)}%  ${k}`);
