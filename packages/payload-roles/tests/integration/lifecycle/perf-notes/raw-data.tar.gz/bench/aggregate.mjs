import { readFileSync } from "node:fs";
const files = process.argv.slice(2);
const runs = files.map((f) => JSON.parse(readFileSync(f, "utf8")));
const sides = ["member", "memberWarm", "superAdmin", "trusted"];
const ops = Object.keys(runs[0].timing);
const med = (xs) => { const s = xs.toSorted((a, b) => a - b); return s[Math.floor(s.length / 2)]; };
const f3 = (x) => x.toFixed(3);
console.log("meta:", runs.map((r) => `${r.meta.timestamp} load ${r.meta.loadAvgStart[0]}->${r.meta.loadAvgEnd[0]} wall ${r.meta.wallSeconds}s`).join(" | "));
console.log("dataset:", runs.map((r) => JSON.stringify(r.dataset)).join(" | "));
let errors = 0;
for (const r of runs) for (const op of ops) for (const s of Object.values(r.timing[op])) errors += s.errors;
for (const r of runs) for (const op of ops) for (const s of Object.values(r.counts[op])) errors += s.errors;
console.log("total errors across runs:", errors);
console.log("\n| op | side | median ms (median of 3 runs) | run medians range | spread | p95 ms (median) | p95 range |");
console.log("|---|---|---|---|---|---|---|");
for (const op of ops) for (const side of sides) {
  const st = runs.map((r) => r.timing[op][side]).filter(Boolean);
  if (st.length === 0) continue;
  const m = st.map((s) => s.medianMs), p = st.map((s) => s.p95Ms);
  const spread = (Math.max(...m) - Math.min(...m)) / med(m) * 100;
  console.log(`| ${op} | ${side} | ${f3(med(m))} | ${f3(Math.min(...m))}-${f3(Math.max(...m))} | ${spread.toFixed(1)}% | ${f3(med(p))} | ${f3(Math.min(...p))}-${f3(Math.max(...p))} |`);
}
console.log("\n| op | member-trusted ms (per run) | memberWarm-trusted | superAdmin-trusted | member-memberWarm (roles lookup) |");
console.log("|---|---|---|---|---|");
for (const op of ops) {
  const d = (a, b) => runs.map((r) => r.timing[op][a] && r.timing[op][b] ? f3(r.timing[op][a].medianMs - r.timing[op][b].medianMs) : "-").join(", ");
  console.log(`| ${op} | ${d("member","trusted")} | ${d("memberWarm","trusted")} | ${d("superAdmin","trusted")} | ${d("member","memberWarm")} |`);
}
console.log("\ncounts identical across runs:");
const strip = (c) => JSON.stringify(c);
for (const op of ops) for (const side of sides) {
  const cs = runs.map((r) => r.counts[op][side] && strip(r.counts[op][side].counts));
  if (!cs[0]) continue;
  if (!cs.every((c) => c === cs[0])) console.log(`  DIFF ${op} ${side}`);
}
console.log("  (no DIFF lines = identical)");
const want = ["db.findOne", "db.findGlobal", "db.find", "db.findVersions", "db.findGlobalVersions", "subject"];
console.log("\n| op | side | findOne | findGlobal | find | findVersions | findGlobalVersions | subject | all db calls |");
console.log("|---|---|---|---|---|---|---|---|---|");
for (const op of ops) for (const side of sides) {
  const e = runs[0].counts[op][side]; if (!e) continue;
  const tot = {}; let all = 0;
  for (const [k, v] of Object.entries(e.counts)) {
    if (k.includes(" <- ")) continue;
    const n = typeof v === "number" ? v : `${v.min}..${v.max}`;
    const method = k.split(" ")[0];
    if (method.startsWith("db.") && !/Transaction$/.test(method)) all += typeof v === "number" ? v : v.max;
    tot[method] = tot[method] === undefined ? n : (typeof tot[method] === "number" && typeof n === "number" ? tot[method] + n : `${tot[method]}+${n}`);
  }
  const detail = (m) => { const parts = Object.entries(e.counts).filter(([k]) => !k.includes(" <- ") && k.split(" ")[0] === m).map(([k, v]) => `${k.split(" ")[1]}:${typeof v === "number" ? v : v.min + ".." + v.max}`); return parts.length ? parts.join(" ") : "0"; };
  console.log(`| ${op} | ${side} | ${detail("db.findOne")} | ${detail("db.findGlobal")} | ${detail("db.find")} | ${detail("db.findVersions")} | ${detail("db.findGlobalVersions")} | ${tot.subject ?? 0} | ${all} |`);
}
console.log("\nsubject callers (run1, member):");
for (const op of ops) { const e = runs[0].counts[op].member; console.log(" ", op, Object.entries(e.counts).filter(([k]) => k.startsWith("subject <- ")).map(([k, v]) => `${k.slice(11)}=${JSON.stringify(v)}`).join(" ")); }
console.log("\nplugin-originated db calls (run1, all sides):");
for (const op of ops) for (const side of sides) { const e = runs[0].counts[op][side]; if (!e) continue; const x = Object.entries(e.counts).filter(([k]) => k.includes(" <- roles:")); if (x.length) console.log(" ", op, side, x.map(([k, v]) => `${k}=${JSON.stringify(v)}`).join(" ")); }
