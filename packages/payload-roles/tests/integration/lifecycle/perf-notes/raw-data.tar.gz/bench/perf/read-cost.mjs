// Cost of the lifecycle's row read itself: payload.db.findOne of one page by id, the whole row
// against the two state columns, alternated in one process on sqlite :memory:.
//   cd packages/payload-roles && node read-cost.mjs <thin|wide>
// Prints one JSON line: per-call medians (µs) per round for each side, and one trusted update.
import os from "node:os";
import { performance } from "node:perf_hooks";
import { pathToFileURL } from "node:url";

const shape = process.argv[2] ?? "thin";
const { createTestPayload, fixtureCollections } = await import(
  pathToFileURL(`${process.cwd()}/tests/helpers/payload.ts`)
);
const collections = fixtureCollections();
if (shape === "wide") {
  collections
    .find((collection) => collection.slug === "pages")
    .fields.push(
      { name: "sections", type: "array", fields: [{ name: "heading", type: "text" }, { name: "body", type: "textarea" }] },
      { name: "tags", type: "text", hasMany: true },
    );
}
const context = await createTestPayload({ name: `read-cost-${shape}`, collections });
const { payload } = context;
const extras =
  shape === "wide"
    ? {
        sections: Array.from({ length: 5 }, (_unused, index) => ({ body: `body ${index} `.repeat(40), heading: `heading ${index}` })),
        tags: ["alpha", "beta", "gamma"],
      }
    : {};
const PAGES = 1000;
const ids = [];
for (let index = 0; index < PAGES; index += 1) {
  ids.push((await payload.create({ collection: "pages", data: { ...extras, _status: "published", title: `base ${index}` } })).id);
}
const select = { _status: true, deletedAt: true };
const read = (id, withSelect) =>
  payload.db.findOne({ collection: "pages", where: { id: { equals: id } }, ...(withSelect && { select }) });

const ROUNDS = 7;
const CALLS = 400;
const median = (values) => values.toSorted((a, b) => a - b)[Math.floor(values.length / 2)];
let wrong = 0;
const sample = async (withSelect) => {
  const times = [];
  for (let call = 0; call < CALLS; call += 1) {
    const id = ids[(call * 37) % PAGES];
    const start = performance.now();
    const row = await read(id, withSelect);
    times.push(performance.now() - start);
    if (row?.id !== id || row._status !== "published" || row.deletedAt !== null) {
      wrong += 1;
    }
  }
  return Math.round(median(times) * 1000);
};
await sample(false);
await sample(true);
const full = [];
const state = [];
for (let round = 0; round < ROUNDS; round += 1) {
  if (round % 2 === 0) {
    full.push(await sample(false));
    state.push(await sample(true));
  } else {
    state.push(await sample(true));
    full.push(await sample(false));
  }
}
const updates = [];
for (let index = 0; index < 60; index += 1) {
  const start = performance.now();
  await payload.update({ collection: "pages", data: { _status: "published", title: `edit ${index}` }, id: ids[index] });
  updates.push(performance.now() - start);
}
console.log(
  JSON.stringify({
    shape,
    node: process.version,
    load: os.loadavg().map((value) => Math.round(value * 100) / 100),
    pages: PAGES,
    callsPerRound: CALLS,
    wrongRows: wrong,
    fullRowUs: full,
    stateColumnsUs: state,
    medianFullUs: median(full),
    medianStateUs: median(state),
    trustedUpdateMedianUs: Math.round(median(updates) * 1000),
  }),
);
await context.destroy();
