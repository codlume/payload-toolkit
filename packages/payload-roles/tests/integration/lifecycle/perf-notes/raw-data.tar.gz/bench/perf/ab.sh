#!/bin/zsh
# Alternates benchmark runs over prebuilt dists: ab.sh <prefix> <runs> <label>... (labels name dirs in dists/).
# Each run copies that dist into the package, so every side runs the same harness file.
# Extra env (BENCH_OPS, BENCH_ITERATIONS, ...) passes through.
set -e
export PATH="$HOME/.nvm/versions/node/v24.22.2/bin:$PATH"
HERE=${0:A:h}
PKG=/private/tmp/claude-501/-Users-paulagolanska--t3-worktrees-payload-toolkit-t3-c8f5859f/abce2a77-9974-4504-b5b9-7ad65f39ef3a/scratchpad/wt/perf/packages/payload-roles
prefix=$1; runs=$2; shift 2
for i in $(seq 1 $runs); do
  for label in "$@"; do
    rm -rf $PKG/dist && cp -R $HERE/dists/$label $PKG/dist
    out=$HERE/runs/$prefix-$label-run$i.json
    echo "$(date +%H:%M:%S) $prefix $label run $i dist $(md5 -q $PKG/dist/index.mjs) load $(sysctl -n vm.loadavg)"
    (cd $PKG && node tests/integration/lifecycle/perf.bench.ts --out $out > /dev/null 2> $HERE/runs/$prefix-$label-run$i.err) || echo "FAILED $out"
  done
done
echo done
