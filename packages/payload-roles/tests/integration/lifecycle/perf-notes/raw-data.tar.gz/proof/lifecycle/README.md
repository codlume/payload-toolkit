# Lifecycle proof (nonsecret, uncommitted)

Branch `feat/roles-lifecycle-enforcement`, base `feat/roles-core` @ daf6cbe95b598fce876657b56a0e73af7062c3c2
(fast-forwarded from the earlier approved base 593e685). Head under test: 46aeac3. Node v24.22.2.
SQLite in-memory (`@payloadcms/db-sqlite`) only. No Postgres or Mongo run.

| Command (from repo root) | Result | Log |
| --- | --- | --- |
| `pnpm --filter @codlume/payload-roles test:unit` | 6 files, 175/175 | head/unit.log |
| `pnpm --filter @codlume/payload-roles exec vitest run tests/integration --maxWorkers=1` (run 1) | 23 files, 590/591 | head/integration.log |
| same, run 2 | 23 files, 590/591 | head/integration.run2.log |
| `pnpm_config_strict_dep_builds=false node packages/payload-roles/tests/compat/run.mjs 3.93.0` | payload 3.93.0: unit 175/175, integration 590/591 | head/compat-3.93.0.log |
| `pnpm exec vp fmt --check packages/payload-roles` | pass | head/fmt.log |
| `pnpm exec vp lint packages/payload-roles --deny-warnings --report-unused-disable-directives` | pass | head/lint.log |
| `packages/payload-roles/node_modules/.bin/tsc -p packages/payload-roles/tsconfig.json --noEmit` | pass | head/tsc.log |
| `pnpm --filter @codlume/payload-roles test:build` | 7/7 | head/build.log |

The single failure in every integration run is core-owned
`tests/integration/core/startup.test.ts > startup warns that lifecycle enforcement is not installed`.
It pins the interim state (`enforcing: false`). The contract defines `enforcing` as false only "while the
interim rule stands", so a correct lifecycle module must fail it. Blocker for core: delete or invert that test.
`tests/integration/lifecycle/isolation.test.ts` already asserts the warning is absent.

Lifecycle files (all pass): tests/unit/lifecycle/rules.test.ts (153), tests/integration/lifecycle/
{collections 122, trash-bulk 33, versions-globals 146, isolation 209, surfaces 18, floor 3}.

Baseline before any lifecycle change: baseline/README.md.

## Final PR head eb7e4617727254a1b7deadeae528174a991f9198 (PR https://github.com/codlume/payload-toolkit/pull/128)

| Command | Result | Log |
| --- | --- | --- |
| `pnpm --filter @codlume/payload-roles test:unit` | 6 files, 177/177 | head/unit-eb7e461.log |
| `pnpm --filter @codlume/payload-roles exec vitest run tests/integration --maxWorkers=1` | 24 files, 597/598 (only core startup test fails) | head/integration-eb7e461.log |
| `pnpm --filter @codlume/payload-roles test:build` | 7/7 | head/build-eb7e461.log |
| `pnpm_config_strict_dep_builds=false node packages/payload-roles/tests/compat/run.mjs 3.93.0` | unit 177/177, integration 597/598 (same core test) | head/compat-3.93.0-eb7e461.log |
| trial merge of eb7e461 with origin/feat/roles-core dc1ca40 (scratch worktree, not published) | unit 177/177, integration 599/599 (25 files), test:build 8/8 | head/trial-*.log, head/trial-merge-dc1ca40.log |

Lifecycle files: tests/unit/lifecycle/rules.test.ts 155; integration collections 122, trash-bulk 33,
versions-globals 146, isolation 209, surfaces 18, floor 3, regressions 7.
Regression tests 13e6beb/eb7e461 fail on the pre-fix head: head/regressions-on-46aeac3.log.
Core defect reproductions: repro/EVIDENCE.md, repro/run.sh, repro/*.log.

## Head c050601ba7d7ae2fcdf2c41b755f3b8c8659efc3 (adds tests/integration/lifecycle/deleted-at-null.test.ts)

| Command | Result | Log |
| --- | --- | --- |
| `pnpm --filter @codlume/payload-roles exec vitest run tests/integration/lifecycle/deleted-at-null.test.ts --maxWorkers=1` (3.90.1) | 8/8 | (run inline) |
| same file on interim stub daf6cbe | 7 failed, 1 passed (stub demands trash for any deletedAt key) | head/deleted-at-null-on-interim-daf6cbe.log |
| `pnpm --filter @codlume/payload-roles exec vitest run tests/integration/lifecycle --maxWorkers=1` (3.90.1) | 8 files, 546/546 | head/lifecycle-c050601.log |
| `pnpm_config_strict_dep_builds=false node packages/payload-roles/tests/compat/run.mjs 3.93.0` | unit 177/177, integration 605/606 (only core startup test) | head/compat-3.93.0-c050601.log |
| local branch lifecycle/nested-direct-coverage 0897b0d: `vitest run tests/integration/lifecycle/nested-direct.test.ts` | 12 failed (reproduced leak), 2 controls passed | head/nested-direct-c050601.log |

## Core 776e512 merged (0fbbecf), coverage merged (f2b8d6c), scope adopted (0ffd1606bd175b72337a677065886c3ca06501e3)

| Command | Result | Log |
| --- | --- | --- |
| nested-direct.test.ts at f2b8d6c (core merged, lifecycle not adopted), Node 24.22.2 | 12 failed, 2 passed | head/nested-direct-before-adoption.log |
| `pnpm --filter @codlume/payload-roles test:unit` (Node 24.22.2) | 6 files, 178/178 | head/unit-0ffd160.log |
| `pnpm --filter @codlume/payload-roles test:integration` (Node 24.22.2, Payload 3.90.1) | 30 files, 680/680 | head/integration-0ffd160.log |
| `pnpm --filter @codlume/payload-roles test:build` | 8/8 | head/build-0ffd160.log |
| `env -u pnpm_config_dangerously_allow_all_builds -u pnpm_config_strict_dep_builds node packages/payload-roles/tests/compat/run.mjs 3.93.0` (Node 24.22.2) | unit 178/178, integration 680/680 | head/compat-3.93.0-0ffd160.log |
| same with `3.90.1` (Node 22.12.0) | unit 178/178, integration 680/680 | head/compat-3.90.1-node22-0ffd160.log |
| Node 22.12.0 `node node_modules/vitest/vitest.mjs run` nested-direct, deleted-at-null, regressions, core hook-order | 4 files, 33/33 | head/focused-node22-0ffd160.log |
| `proof/lifecycle/repro/run.sh <checkout>` (orderable + direct-operation repro) | 6/6 | repro/lifecycle-0ffd160.log |

Node 22 note: pnpm 11.10.0 refuses Node 22.12.0 (needs >= 22.13), so the standalone pnpm call failed to start;
the compat runner and the direct vitest call above ran the tests on 22.12.0.

## Final head a5f2c0bfd9286a88f331be7d8cb01fef11f7e00a (core a05cdb9 merged) — PR #128

| Command | Result | Log |
| --- | --- | --- |
| `pnpm --filter @codlume/payload-roles test:unit` (Node 24.22.2) | 8 files, 206/206 | head/unit-a5f2c0b.raw.log |
| `pnpm --filter @codlume/payload-roles test:integration` (Node 24.22.2, Payload 3.90.1) | 33 files, 742/742 | head/integration-a5f2c0b.raw.log |
| `pnpm --filter @codlume/payload-roles test:build` | 8/8 | head/build-a5f2c0b.log |
| `vp fmt --check`, `vp lint --deny-warnings`, `tsc --noEmit` (packages/payload-roles) | pass | head/static-a5f2c0b.log |
| `node packages/payload-roles/tests/compat/run.mjs 3.93.0` (Node 24.22.2) | 206 + 742 | head/compat-3.93.0-a5f2c0b.raw.log |
| `node packages/payload-roles/tests/compat/run.mjs 3.90.1` (Node 22.12.0) | 206 + 742 | head/compat-3.90.1-node22-a5f2c0b.raw.log |
| Node 22.12.0 vitest: nested-direct, rewritten-id, deleted-at-null, regressions, core hook-order | 5 files, 65/65 | head/focused-node22-a5f2c0b.raw.log |
| `proof/lifecycle/repro/run.sh <checkout>` | 6/6 | repro/lifecycle-a5f2c0b.raw.log |
| PR #128 CI on a5f2c0b | all 7 checks passed (Macroscope skipped) | GitHub |
| Third independent review, delta check of a5f2c0b | SHIP | (subagent report) |

## Final head 1ffaa2860bf2deccf95de21578f57e5ae8b269c7 (core race fix 38e69b5 merged)

Unit 206/206, integration 742/742 (33 files), test:build 8/8, fmt+lint+tsc clean, compat 3.93.0/Node 24.22.2
and 3.90.1/Node 22.12.0 each 206 + 742, focused Node 22.12.0 65/65, repro 6/6 (logs head/*-1ffaa28*).
PR #128 CI: all 7 checks passed on 1ffaa28 (Macroscope skipped).
