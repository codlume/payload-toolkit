// Reproduction: `orderable: true` on a collection that carries trailing roles-plugin
// `beforeChange` hooks fails startup, because Payload's sanitizer appends its own
// `orderBeforeChangeHook` after every plugin ran (payload/dist/config/sanitize.js:251 ->
// config/orderable/index.js:100) and core's `tracker.verify` (src/hooks.ts:565-593, called from
// src/plugin.ts:183) requires the plugin's trailing hooks to stay last.
// Each test asserts the CORRECT behavior (startup succeeds), so it fails while the defect exists.
import { expect, test } from "vitest";

import { createTestPayload, defaultRolesOptions, fixtureCollections } from "../../../helpers/payload.ts";

const orderable = (slug: string) =>
  fixtureCollections().map((collection) =>
    collection.slug === slug ? Object.assign(collection, { orderable: true }) : collection,
  );

test("control: an orderable collection with no roles-plugin hooks starts", async () => {
  const context = await createTestPayload({ collections: orderable("posts"), name: "repro-orderable-posts" });
  await context.destroy();
});

test("an orderable managed drafts collection (pages) starts", async () => {
  const context = await createTestPayload({ collections: orderable("pages"), name: "repro-orderable-pages" });
  await context.destroy();
});

test("an orderable managed users collection starts", async () => {
  const context = await createTestPayload({
    collections: orderable("users"),
    name: "repro-orderable-users",
    roles: defaultRolesOptions(),
  });
  expect(context.payload.collections.users).toBeDefined();
  await context.destroy();
});
