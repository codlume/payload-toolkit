# Reproductions for core: orderable startup and direct-operation trust leak

Run from any machine path: `proof/lifecycle/repro/run.sh <checkout-root>` (this folder:
`/Users/paulagolanska/.t3/worktrees/payload-toolkit/t3-c8f5859f/proof/lifecycle/repro/`). The script copies
`*.repro.test.ts` into `<checkout>/packages/payload-roles/tests/integration/lifecycle/_repro/`, builds the
package, runs `pnpm --filter @codlume/payload-roles exec vitest run tests/integration/lifecycle/_repro
--maxWorkers=1`, and deletes the copied folder. Each test asserts the CORRECT behavior, so a failure is the
defect. Tested on Payload 3.90.1, Node v24.22.2, SQLite in memory (`tests/helpers/payload.ts`).

| Checkout | SHA | Logs |
| --- | --- | --- |
| core alone (interim lifecycle, no lifecycle hooks) | daf6cbe95b598fce876657b56a0e73af7062c3c2 | core-alone-daf6cbe.log |
| lifecycle installed | 13e6bebdc298000d5706373c81edf4107e5f6876 | lifecycle-13e6beb.log |

## 1. Orderable collection fails startup (`orderable.repro.test.ts`)

| Test | core alone | with lifecycle |
| --- | --- | --- |
| control: an orderable collection with no roles-plugin hooks starts (`posts`) | pass | pass |
| an orderable managed drafts collection (pages) starts | pass | FAIL |
| an orderable managed users collection starts | FAIL | FAIL |

Expected: startup succeeds. Actual: `RolesPluginConfigError: Invalid Roles plugin configuration: - Hooks were
placed around the roles plugin's own on "collections:users" \`beforeChange\` after it ran. Register
rolesPlugin after every plugin that adds hooks there.` (pages variant names `collections:pages`), thrown from
`onInit` (dist/index.mjs:1745 at 13e6beb).

Cause: Payload's sanitizer appends `orderBeforeChangeHook` to `collection.hooks.beforeChange` after all
plugins ran (payload/dist/config/sanitize.js:251 -> config/orderable/index.js:100). Core's
`createHookTracker().inPlace` requires the plugin's trailing hooks to be the last entries
(src/hooks.ts:565-571, verify 574-593, called at src/plugin.ts:183, thrown at :186). Core alone reproduces it
on the users collection (core's trailing users guards); lifecycle adds trailing `beforeChange` hooks on every
drafts/trash/versions resource, which extends it to those. The appended hook only writes `_order`.
Reordering plugins cannot fix it. Smallest proposal: core's check tolerates hooks that Payload's own
sanitizer appends after plugins (the orderable hook), or documents orderable as unsupported.

## 2. Direct operation call with `disableTransaction: true` leaks trust (`direct-operation.repro.test.ts`)

| Test | core alone | with lifecycle |
| --- | --- | --- |
| lifecycle: an update-only member cannot edit a live page when an app hook runs a direct trusted operation | pass (interim access refuses earlier) | FAIL: 200, live title changed |
| core: a users editor's Local API write cannot change a super admin's email when an app hook runs a direct trusted operation | FAIL: allowed, email changed | FAIL: allowed, email changed |
| control: without the direct operation the same Local API write is refused | pass | pass |

Fixture: an app `beforeChange` hook on `users`/`pages` (runs before core and lifecycle hooks) calls
`updateByIDOperation({ collection, id: <another doc>, data: {}, req, overrideAccess: true,
disableTransaction: true, depth: 0 })` (exported from `payload`) once per member request.

Expected: the outer member write is judged on its own record and refused. Actual (core alone):
`{ outcome: "allowed", email: "attacker@example.com" }` instead of `{ outcome: "Forbidden", email:
"victim@example.com" }` for a users editor changing a super admin's email (account takeover path).
Actual (lifecycle): REST `PATCH /pages/:id {title}` by a read+update member returns 200 and the live
published row's title changes, instead of 403.

Cause: `updateByIDOperation` skips its first await when `disableTransaction` is set
(payload/dist/collections/operations/updateByID.js:24: `!args.disableTransaction && await
initTransaction(...)`), so `buildBeforeOperation` (:61) calls the opener synchronously in the caller's turn.
The opener's `enterWith` (core src/hooks.ts:94 in `createRecorder`; lifecycle `open` in
src/lifecycle/index.ts) then replaces the store of the OUTER operation, whose later hooks read it
(core src/hooks.ts:253-254 `operations.getStore() ?? untrusted()` then `if (current.trusted)`). Payload's
Local API wrappers (`payload.update`) await `createLocalReq` first and are not affected; only direct
operation calls with `disableTransaction: true` are. Over REST, core is not affected because core also
requires `req.payloadAPI === "local"` and the nested call reuses the REST req; lifecycle trusts
`overrideAccess === true` alone, so it is affected over REST too. An outer Local API call
(`overrideAccess: false`) has `payloadAPI: "local"`, so both are affected there.

Not fixed in either module. It is shared opener infrastructure (contract `LeadingBeforeOperation`).
