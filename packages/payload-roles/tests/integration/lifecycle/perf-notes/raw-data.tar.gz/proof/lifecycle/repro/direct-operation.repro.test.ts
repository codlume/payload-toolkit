// Reproduction: an app hook that calls an exported Payload operation function directly with
// `disableTransaction: true` and `overrideAccess: true` reaches the nested operation's first
// `beforeOperation` hook synchronously, in the caller's turn (payload/dist/collections/operations/
// updateByID.js:24 skips `await initTransaction` when `disableTransaction` is set; :61
// buildBeforeOperation calls the opener before any await). The nested opener's `enterWith`
// (core src/hooks.ts:94, lifecycle src/lifecycle/index.ts `open`) then replaces the OUTER
// operation's store, so the outer untrusted write is judged as trusted.
// Each test asserts the CORRECT behavior (outer write refused), so it fails while the defect exists.
// The Local API wrappers (payload.update) await createLocalReq first and are not affected.
import { type CollectionConfig, updateByIDOperation } from "payload";
import { afterAll, beforeAll, expect, test } from "vitest";

import { type Actor, as, login, rest, seedRole, seedUser } from "../../../helpers/actors.ts";
import {
  createTestPayload,
  defaultRolesOptions,
  fixtureCollections,
  type TestPayload,
} from "../../../helpers/payload.ts";

let context: TestPayload;
let nestedTargets: { pages: number | string; users: number | string };

const directTrustedUpdate =
  (slug: "pages" | "users"): NonNullable<CollectionConfig["hooks"]>["beforeChange"] =>
  [
    async ({ data, req }) => {
      const collection = req.payload.collections[slug];
      if (collection && req.user && nestedTargets[slug] !== "" && req.context.reproNested !== true) {
        req.context.reproNested = true;
        await updateByIDOperation({
          collection,
          data: {},
          depth: 0,
          disableTransaction: true,
          id: nestedTargets[slug],
          overrideAccess: true,
          req,
        });
      }
      return data;
    },
  ];

let actors: Record<"pagesUpdateOnly" | "usersEditor" | "victim", Actor>;
let liveId: number | string;

beforeAll(async () => {
  context = await createTestPayload({
    collections: fixtureCollections().map((collection) =>
      collection.slug === "pages" || collection.slug === "users"
        ? Object.assign(collection, {
            hooks: { ...collection.hooks, beforeChange: directTrustedUpdate(collection.slug) },
          })
        : collection,
    ),
    name: "repro-direct-operation",
    roles: defaultRolesOptions(),
  });
  const { payload } = context;
  nestedTargets = { pages: "", users: "" };
  await seedUser(payload, { email: "bootstrap@example.com" });
  actors = {
    pagesUpdateOnly: await seedUser(payload, {
      email: "pages-update-only@example.com",
      roles: [await seedRole(payload, "pages-update-only", { collections: { pages: { actions: ["read", "update"] } } })],
    }),
    usersEditor: await seedUser(payload, {
      email: "users-editor@example.com",
      roles: [await seedRole(payload, "users-editor", { collections: { users: { actions: ["read", "update"] } } })],
    }),
    victim: await seedUser(payload, { email: "victim@example.com", superAdmin: true }),
  };
  const other = await payload.create({ collection: "pages", data: { _status: "published", title: "nested target" } });
  liveId = (await payload.create({ collection: "pages", data: { _status: "published", title: "live" } })).id;
  nestedTargets = { pages: other.id, users: actors.usersEditor.id };
});

afterAll(() => context.destroy());

test("lifecycle: an update-only member cannot edit a live page when an app hook runs a direct trusted operation", async () => {
  const api = rest(context, await login(context.payload, actors.pagesUpdateOnly.email));
  const response = await api("PATCH", `/pages/${liveId}`, { title: "edited without publish" });
  const row = await context.payload.db.findOne({ collection: "pages", where: { id: { equals: liveId } } });

  expect({ status: response.status, title: row?.title }).toEqual({ status: 403, title: "live" });
});

// Over REST core is not affected: the leaked record is untrusted because core also requires
// req.payloadAPI === "local", and the nested call reuses the REST req. An outer Local API call
// with overrideAccess: false has payloadAPI "local", so the leaked core record is trusted.
const changeVictimEmail = async (email: string) => {
  try {
    await as(context.payload, actors.usersEditor).update({ collection: "users", data: { email }, id: actors.victim.id });
    return "allowed";
  } catch (error) {
    return error instanceof Error ? error.name : "error";
  }
};

test("core: a users editor's Local API write cannot change a super admin's email when an app hook runs a direct trusted operation", async () => {
  const outcome = await changeVictimEmail("attacker@example.com");
  const row = await context.payload.db.findOne({ collection: "users", where: { id: { equals: actors.victim.id } } });

  expect({ outcome, email: row?.email }).toEqual({ outcome: "Forbidden", email: "victim@example.com" });
});

test("control: without the direct operation the same Local API write is refused", async () => {
  nestedTargets = { ...nestedTargets, users: "" };
  const outcome = await changeVictimEmail("control@example.com");
  nestedTargets = { ...nestedTargets, users: actors.usersEditor.id };

  expect(outcome).toBe("Forbidden");
});
