#!/usr/bin/env bash
# Runs the reproductions in this folder against a checkout of payload-toolkit.
# Usage: proof/lifecycle/repro/run.sh <checkout-root>
# Needs Node 24 (tested v24.22.2) and an installed checkout (`pnpm install --frozen-lockfile`).
# Copies the files into <checkout>/packages/payload-roles/tests/integration/lifecycle/_repro/
# (an untracked lifecycle path), builds the package, runs vitest, then deletes that folder.
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
checkout="$(cd "${1:?pass the checkout root}" && pwd)"
target="${checkout:?}/packages/payload-roles/tests/integration/lifecycle/_repro"
mkdir -p "${target:?}"
cp "${here:?}"/*.repro.test.ts "${target:?}/"
trap 'rm -rf "${target:?}"' EXIT
cd "${checkout:?}"
echo "checkout HEAD: $(git rev-parse HEAD)  node: $(node -v)"
pnpm --filter @codlume/payload-roles build >/dev/null
pnpm --filter @codlume/payload-roles exec vitest run tests/integration/lifecycle/_repro --maxWorkers=1 || true
