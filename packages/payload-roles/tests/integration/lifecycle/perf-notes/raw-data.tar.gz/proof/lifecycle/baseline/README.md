# Baseline on feat/roles-core 593e685 (before lifecycle changes)

Node v24.22.2 (`~/.nvm/versions/node/v24.22.2`).

| Command | Result |
| --- | --- |
| `pnpm --filter @codlume/payload-roles test:unit` | 5 files, 22 tests passed |
| `pnpm --filter @codlume/payload-roles exec vitest run tests/integration --maxWorkers=1` | 17 files, 65 tests passed |
| `pnpm_config_strict_dep_builds=false node packages/payload-roles/tests/compat/run.mjs 3.93.0` | payload 3.93.0 installed; unit 22/22, integration 65/65 |

The compat runner fails at install on pnpm 11.10.0 without `pnpm_config_strict_dep_builds=false`
(`ERR_PNPM_IGNORED_BUILDS` for esbuild). `ERR_PNPM_MINIMUM_RELEASE_AGE_VIOLATION` lines printed during the
run did not fail it. Runner file is core-owned and unchanged.
